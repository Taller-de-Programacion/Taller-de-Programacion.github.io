/*
 * Basado en un ejemplo de http://library.gnome.org/devel/gtkmm-tutorial
 *
 * Para m�s informaci�n. Remitirse al cap�lo 18.Printing del tutorial.
 *
 * Se compila utilizando el comando make
 *
 */

#include <gtkmm/main.h>
#include "ExampleWindow.h"

int main(int argc, char *argv[])
{
  Gtk::Main kit(argc, argv);

  ExampleWindow window;
  Gtk::Main::run(window);

  return 0;
}
