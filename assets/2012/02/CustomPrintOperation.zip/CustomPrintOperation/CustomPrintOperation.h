#ifndef GTKMM_CUSTOM_PRINT_OPERATION_H
#define GTKMM_CUSTOM_PRINT_OPERATION_H

#include <gtkmm.h>
#include <vector>

class CustomPrintOperation : public Gtk::PrintOperation
{
public:
	static Glib::RefPtr<CustomPrintOperation> create();

protected:
	virtual void on_begin_print(const Glib::RefPtr<Gtk::PrintContext>& context);
	virtual void on_draw_page(const Glib::RefPtr<Gtk::PrintContext>& context, int page_nr);

};

#endif // GTKMM_PRINT_FORM_OPERATION_H
