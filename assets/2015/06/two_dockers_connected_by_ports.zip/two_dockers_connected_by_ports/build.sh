#! /bin/bash
sudo docker build -t sandbox-server-client .

