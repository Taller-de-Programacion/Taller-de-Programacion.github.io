#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
   struct addrinfo hints;
   struct addrinfo *result, *ptr;

   int bytes_sent = 0;
   int bytes_recv = 0;

   if (argc != 3) {
       printf("IP and Port number required\n");
       return 1; 
   }

   memset(&hints, 0, sizeof(struct addrinfo));
   hints.ai_family = AF_INET;       /* IPv4 (or AF_INET6 for IPv6)     */
   hints.ai_socktype = SOCK_STREAM; /* TCP  (or SOCK_DGRAM for UDP)    */
   hints.ai_flags = 0;              /* None (or AI_PASSIVE for server) */

   int s = getaddrinfo(argv[1], argv[2], &hints, &result);

   if (s != 0) { 
      printf("Error in getaddrinfo: %s\n", gai_strerror(s));
      return 1;
   }
   int skt = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
   if (skt == -1) {
       printf("Error: %s\n", strerror(errno));
       return 1;
   }
   else {
       s = connect(skt, result->ai_addr, result->ai_addrlen);
       if (s == -1) {
           printf("Error: %s\n", strerror(errno));
           close(skt);
           return 1;
       }
   }
   
   freeaddrinfo(result);

   char response;
   int received;
   printf("Receiving message...\n");
   do {
       received = recv(skt, &response, 1, MSG_NOSIGNAL);
   } while(!received);
   printf("Message received: %c\n", response);

   shutdown(skt, SHUT_RDWR);
   close(skt);
   return 0;
}

