#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

int sendMessage(int skt) {
   char msg = 'A';
   int sent;
   do {
       sent = send(skt, &msg, 1, MSG_NOSIGNAL);
   } while(!sent);
}

int main(int argc, char *argv[]) {
   struct addrinfo hints;
   struct addrinfo *ptr;

   if (argc != 2) {
       printf("Port number required\n");
       return 1; 
   }

   memset(&hints, 0, sizeof(struct addrinfo));
   hints.ai_family = AF_INET;       /* IPv4 (or AF_INET6 for IPv6)     */
   hints.ai_socktype = SOCK_STREAM; /* TCP  (or SOCK_DGRAM for UDP)    */
   hints.ai_flags = AI_PASSIVE;     /* AI_PASSIVE for server           */

   int s = getaddrinfo(NULL, argv[1], &hints, &ptr);

   if (s != 0) { 
      printf("Error in getaddrinfo: %s\n", gai_strerror(s));
      return 1;
   }

   int skt = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);

   if (skt == -1) {
      printf("Error: %s\n", strerror(errno));
      freeaddrinfo(ptr);
      return 1;
   }

   s = bind(skt, ptr->ai_addr, ptr->ai_addrlen);
   if (s == -1) {
      printf("Error: %s\n", strerror(errno));
      close(skt);
      freeaddrinfo(ptr);
      return 1;
   }

   freeaddrinfo(ptr);

   s = listen(skt, 20);
   if (s == -1) {
      printf("Error: %s\n", strerror(errno));
      close(skt);
      return 1;
   }

   printf("Accepting connections at %s...\n", argv[1]);
   int peerskt = accept(skt, NULL, NULL);   // aceptamos un cliente
   if (peerskt == -1) {
      printf("Error: %s\n", strerror(errno));
   }
   else {
      printf("New client. Sending message...\n");
      sendMessage(peerskt);
      printf("Message sent. Closing connection...\n");
      shutdown(peerskt, SHUT_RDWR);
      close(peerskt);
   }
   
   shutdown(skt, SHUT_RDWR);
   close(skt);

   return 0;
}


