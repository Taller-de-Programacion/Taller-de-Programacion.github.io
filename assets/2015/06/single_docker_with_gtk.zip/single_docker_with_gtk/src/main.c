#include <gtk/gtk.h>

static void destroy( GtkWidget *widget,
                     gpointer   data )
{
    gtk_main_quit();
}

int main( int   argc, char *argv[] )
{
    gtk_init(&argc, &argv);
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    GtkWidget *label = gtk_label_new("Hola Mundo");
    gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(label));
    g_signal_connect(window, "destroy", G_CALLBACK (destroy), NULL);
    gtk_container_set_border_width(GTK_CONTAINER(window), 20);    
    gtk_widget_show_all(window);
    gtk_main();
    
    return 0;
}

